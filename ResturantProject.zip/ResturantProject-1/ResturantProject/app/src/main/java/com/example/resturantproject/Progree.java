package com.example.resturantproject;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.app.Activity;
import android.widget.Button;

import com.example.resturantproject.R;

public class Progree extends Activity {
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progree);
        button=findViewById(R.id.button1);

    }
    public void onClick(View v)
    {
        button.setScaleX(1);
        button.setScaleY(1);
    }
}