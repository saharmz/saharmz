package com.example.resturantproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainPage extends AppCompatActivity {

    TextView textView;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
        textView=findViewById(R.id.textView3);
    }


    public void pizza(View view)
    {
        //ContentValues values=new ContentValues();
        //values.put("order","pizza");
       // Intent goActivity=new Intent(MainPage.this,OkPage.class);
       // startActivity(goActivity);
        Order order=new Order();
        order.setId(1);
        order.setName("بیتزا");
        order.setPrice(150000);
        order.setStatus("درحال اماده سازی");
        Database.currentOrder=order;
        textView.setText("پیتزا مخلوط 2 نفره\n" +
                "قیمت:150 هزار تومان\n" +
                "مدت زمان لازم: 20 دقیقه");



    }

    public void hotdog(View view)
    {
        Order order=new Order();
        order.setId(2);
        order.setName("هات داگ");
        order.setPrice(140000);
        order.setStatus("درحال اماده سازی");
        Database.currentOrder=order;
        //ContentValues values=new ContentValues();
        //values.put("order","hotdog");
       // Intent goActivity=new Intent(MainPage.this,OkPage.class);
       // startActivity(goActivity);
        textView.setText("هات داگ\n" +
                "قیمت:140 هزار تومان\n" +
                "مدت زمان لازم: 20 دقیقه");
    }

    public void fastfood(View view)
    {
        Order order=new Order();
        order.setId(3);
        order.setName("چیزبرگر");
        order.setPrice(90000);
        order.setStatus("درحال اماده سازی");
        Database.currentOrder=order;
       /* ContentValues values=new ContentValues();
        values.put("order","fastfood");
        Intent goActivity=new Intent(MainPage.this,OkPage.class);
        startActivity(goActivity);*/
       textView.setText("چیزبرگر\n" +
               "قیمت:90 هزار تومان\n" +
               "مدت زمان لازم: 20 دقیقه");
    }

    public void hamb(View view)
    {
        Order order=new Order();
        order.setId(4);
        order.setName("همبرگر");
        order.setPrice(70000);
        order.setStatus("درحال اماده سازی");
        Database.currentOrder=order;
       /* ContentValues values=new ContentValues();
        values.put("order","hamb");
        Intent goActivity=new Intent(MainPage.this,OkPage.class);
        startActivity(goActivity);*/
       textView.setText("همبرگر\n" +
               "قیمت:70 هزار تومان\n" +
               "مدت زمان لازم: 10 دقیقه");
    }

    public void french(View view)
    {
        Order order=new Order();
        order.setId(5);
        order.setName("سیب زمینی");
        order.setPrice(50000);
        order.setStatus("درحال اماده سازی");
        Database.currentOrder=order;
        /*ContentValues values=new ContentValues();
        values.put("order","french");
        Intent goActivity=new Intent(MainPage.this,OkPage.class);
        startActivity(goActivity);*/
        textView.setText("سیب زمینی\n" +
                "قیمت:50 هزار تومان\n" +
                "مدت زمان لازم: 15 دقیقه");

    }

    public void diet(View view)
    {
        /*ContentValues values=new ContentValues();
        values.put("order","french");
        Intent goActivity=new Intent(MainPage.this,OkPage.class);
        startActivity(goActivity);*/
        Order order=new Order();
        order.setId(6);
        order.setName("سالاد سزار");
        order.setPrice(80000);
        order.setStatus("درحال اماده سازی");
        Database.currentOrder=order;
        textView.setText("سالاد سزار\n" +
                "قیمت:80 هزار تومان\n" +
                "مدت زمان لازم: 15 دقیقه");
    }
    public void setOrder(View view)
    {

        Database database=new Database();
        database.addToList();
        textView.setText("سفارش شما با موفقیت ثبت شد");

    }


    public void goStatusPage(View view)
    {
        Intent goActivity=new Intent(MainPage.this,OkPage.class);
        startActivity(goActivity);
    }


}
