package com.example.resturantproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    User[]users=new User[2];
    EditText usname;
    EditText psname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initUI();
        initialUsers();
    }

    public void go(View view)
    {
        boolean exists=false;
        for (int i=0;i<2;i++)
        {
            if (users[i].getUserName().equals(usname.getText().toString())&&users[i].getPassword().equals(psname.getText().toString()))
            {
                Database.currentUser=users[i];
                exists=true;
            }
        }

        if (exists==true)
        {
            Intent goActivity=new Intent(MainActivity.this,MainPage.class);
            startActivity(goActivity);
        }


    }

    public void initUI()
    {
        usname=findViewById(R.id.ustxt);
        psname=findViewById(R.id.pstxt);
    }


    public void initialUsers()
    {

        User user1=new User("alix","1234");
        User user2=new User("apak","4321");
        users[0]=user1;
        users[1]=user2;
    }

}
