package com.example.resturantproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class OkPage extends AppCompatActivity {


    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ok_page);
        textView=findViewById(R.id.textView);
        Database database=new Database();
        textView.setText("وضعیت سفارش شما : "+database.getOrderStatus());
    }
}
