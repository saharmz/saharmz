package com.example.resturantproject;

import java.util.HashMap;

public class Database {

   static HashMap<User,Order> orderHashMap=new HashMap<>();
    static Order currentOrder;
   static User currentUser;

    public void addToList(){
        orderHashMap.put(currentUser,currentOrder);

    }
    public String  getOrderStatus(){
        return orderHashMap.get(currentUser).getStatus();

    }


}
